//
//  ViewController.swift
//  Bhumpalli_CurrencyConverter
//
//  Created by Bhumpalli,Srikanth Reddy on 2/24/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var displayName: UITextField!
    
    
    @IBOutlet weak var enterInr: UITextField!


    @IBOutlet weak var enterUsd: UITextField!
    
    @IBOutlet weak var amountDisplayLable: UILabel!
    
    
    @IBOutlet weak var inrDisplay: UILabel!


    @IBOutlet weak var usdToInr: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func convertCurrency(_ sender: UIButton) {
        
        let exchangeRate = 74.64
      
        var num = Int(enterInr.text!)
        var num2 = Int(enterUsd.text!)
        amountDisplayLable.text = "hell0 \(displayName.text!),"
        
        inrDisplay.text = "amount of rs.\(num!) in USD is \(String(Double(num!)/exchangeRate))"
        usdToInr.text = "amount of $ \(num2!)in INR is Rs. \(String(Double(num2!)*exchangeRate))"
        
        
        
    }
    
}

